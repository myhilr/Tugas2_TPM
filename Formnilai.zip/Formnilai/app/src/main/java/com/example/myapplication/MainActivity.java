package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText in_nama = findViewById(R.id.innama);
        EditText in_nim = findViewById(R.id.innim);
        EditText in_nilai = findViewById(R.id.innilai);
        Button button = findViewById(R.id.inbutton);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            try {
                Intent i = new Intent(MainActivity.this, HasilConvert.class);
                i.putExtra("NAMA", in_nama.getText().toString());
                i.putExtra("NIM", in_nim.getText().toString());
                double konvNilai = Double.parseDouble(in_nilai.getText().toString());

                if (konvNilai <= 4.00) {
                    if (konvNilai == 1.00) {
                        i.putExtra("NILAI", "D");
                    } else if (konvNilai <= 1.33) {
                        i.putExtra("NILAI", "D+");
                    } else if (konvNilai <= 1.66) {
                        i.putExtra("NILAI", "C-");
                    } else if (konvNilai <= 2.00) {
                        i.putExtra("NILAI", "C");
                    } else if (konvNilai <= 2.33) {
                        i.putExtra("NILAI", "C+");
                    } else if (konvNilai <= 2.66) {
                        i.putExtra("NILAI", "B-");
                    } else if (konvNilai <= 3.00) {
                        i.putExtra("NILAI", "B");
                    } else if (konvNilai <= 3.33) {
                        i.putExtra("NILAI", "B+");
                    } else if (konvNilai <= 3.66) {
                        i.putExtra("NILAI", "A-");
                    } else {
                        i.putExtra("NILAI", "A");
                    }
                    MainActivity.this.startActivity(i);
                } else {
                    Toast.makeText(MainActivity.this.getApplication(), "Nilai tidak boleh dibawah 1.00", Toast.LENGTH_SHORT).show();
                }
           } catch (Exception e) {
                Toast.makeText(MainActivity.this.getApplication(), "Nilai tidak boleh kosong", Toast.LENGTH_SHORT).show();
            }
            }
        });
    }
}
