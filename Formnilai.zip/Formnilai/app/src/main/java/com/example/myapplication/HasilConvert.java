package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class HasilConvert extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hasil_convert);

        TextView outnama= findViewById(R.id.viewnama);
        TextView outnim= findViewById(R.id.viewnim);
        TextView outnilai= findViewById(R.id.viewnilai);
        Bundle bundle=getIntent().getExtras();
        String s= bundle.getString("NAMA");
        String t= bundle.getString("NIM");
        String u= bundle.getString("NILAI");
        outnama.setText(String.format(": %s", s));
        outnim.setText(String.format(": %s", t));
        outnilai.setText(String.format(": %s", u));

    }
}